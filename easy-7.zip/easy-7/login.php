<?php
  session_start();
  if (isset($_SESSION['username']) && $_SESSION['username'] == 'user') {
    header('location: user.php');
  }
  elseif (isset($_SESSION['username']) && $_SESSION['username'] == 'sunshine') {
    header('location: admin.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    
    <link rel="stylesheet" href="css/bootstrap4-neon-glow.min.css">
    
    
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel='stylesheet' href='//cdn.jsdelivr.net/font-hack/2.020/css/hack.min.css'>
    
  </head>
  <body>

  <div class="navbar-dark text-white">
    <div class="container">
      <nav class="navbar px-0 navbar-expand-lg navbar-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a href="index.html" class="pl-md-0 p-3 text-light">Home</a>
            <a href="form.html" class="p-3 text-decoration-none text-light">Report a bug?</a>
          </div>
        </div>
      </nav>

    </div>
  </div>

  
<div class="container py-5 mb5">
  <h1 class="mb-5">Login</h1>

  <table class="">
    <form action="./loginAuth.php" method="post" class="mb-3">
      Username: <input type="text" name="username" id="username" class="form-control col-md-3"><br>
      Password: <input type="password" name="password" id="password" class="form-control col-md-3"><br>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </table>

</div>
<!--
  <div class="row">
    <div class="col-md-3">
        <form class="mb-3">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search">
            <div class="input-group-append">
              <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </div>
        </form>

        <div class="list-group">
          <a href="#" class="list-group-item list-group-item-action active"> Dashboard </a>
          <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
            Inbox
            <span class="badge badge-primary badge-pill ml-auto">14</span>
          </a>
          <a href="#" class="list-group-item list-group-item-action">Orders</a>
          <a href="#" class="list-group-item list-group-item-action">Products</a>
          <a href="#" class="list-group-item list-group-item-action">Customers</a>
          <a href="#" class="list-group-item list-group-item-action">Reports</a>
        </div>
    </div>
    <div class="col-md-9">

      <div class="row d-none">
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Card title</h4>
              <p class="card-text">
                Some quick example text to build on the card title
                and make up the bulk of the card's content.
              </p>
              <!--<a href="#!" class="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
      </div>

      <table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
  
    <tr>
      <th scope="row">1</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">2</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">3</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">4</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">5</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">6</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">7</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">8</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
    <tr>
      <th scope="row">9</th>
      <td>
        <a href="#">
        Some item on your list
        </a>
      </td>
      <td>
        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
          <span class="fas fa-edit mr-1"></span>
          Edit</a>
        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
          <span class="fas fa-trash mr-1"></span>
          Delete</a>
      </td>
    </tr>
  
  </tbody>
</table>

    </div>
  </div>

</div>-->



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  </body>
</html>
