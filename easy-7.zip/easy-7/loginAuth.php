<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>LoginAuth</title>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    
    <link rel="stylesheet" href="css/bootstrap4-neon-glow.min.css">
    
    
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel='stylesheet' href='//cdn.jsdelivr.net/font-hack/2.020/css/hack.min.css'>
</head>
<body>
    <?php
        if ($_POST["username"] != "sunshine" && $_POST["password"] != "Startrek") {
            echo '<h3 style="text-align:center; margin-top:100px">Wrong username or password.</h3>';
        }
        elseif ($_POST["username"] == "sunshine" && $_POST["password"] != "Startrek") {
            echo '<h3 style="text-align:center; margin-top:100px">Wrong username or password</h3>';
        }
        elseif ($_POST["username"] == "sunshine" && $_POST["password"] == "Startrek" && $_POST["role"] == "user") {
            $_SESSION['username'] = $_POST['username'];
            $_SESSION['password'] = $_POST['password'];
            $_SESSION['role'] = $_POST['role'];
            header('location: user.php');
        }
        elseif ($_POST["username"] == "sunshine" && $_POST["password"] == "Startrek" && $_POST["role"] == "administrator") {
            $_SESSION['username'] = $_POST['username'];
            $_SESSION['password'] = $_POST['password'];
            $_SESSION['role'] = $_POST['role'];
            header('location: admin.php');
        }
        elseif ($_POST['role'] != 'user' || $_POST['role'] != 'administrator') {
            header('location: sus.php');
        }
    ?>
</body>
</html>